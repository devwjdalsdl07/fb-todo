import React from "react";
import KakaoMap from "../components/KakaoMap";

const Home = () => {
  return (
    <div>
      <p>Home</p>
      <KakaoMap />
    </div>
  );
};

export default Home;
